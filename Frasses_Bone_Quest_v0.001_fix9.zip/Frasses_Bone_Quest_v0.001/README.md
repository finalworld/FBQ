# Frasse’s Bone Quest — v0.001 fix 9

Fix 9:
- HUD split into fixed left/right pieces plus a horizontally stretchable centre.
- Player paw and bone markers are added only after the MapLibre style has loaded.
- Dark grass map treatment while keeping water, roads, paths, buildings and street names.
- Cafés, shops and other POIs remain hidden.

# Frasse's Bone Quest v0.001

Första lokala testversionen.

## Innehåll
- Riktig karta via MapLibre
- GPS och följande kamera
- Blå tass som spelarikon
- Lokalt sparad benräknare
- Ben hämtas/genereras från riktiga OSM-gångvägar och stigar inom cirka 3,5 km
- Minst cirka 300 meter mellan genererade ben
- Ta benet-knapp inom 25 meter
- Bildbaserad HUD
- Menyn innehåller endast Stäng appen

## Viktigt vid första starten
Ge appen exakt platsbehörighet. Internet behövs för kartan och för att hämta OSM-stigar, men speldata sparas lokalt. Den offentliga Overpass-tjänsten kan ibland vara långsam; vänta en stund eller starta om appen om inga ben visas.

## Bygga APK
Öppna projektet i Android Studio och välj **Build > Build APK(s)**, eller använd GitHub Actions-filen i `.github/workflows/build-apk.yml`.

## Fix 5
- 12 pixel-art bone sprites included in `drawable-nodpi`; all are worth 1 in v0.001.
- Nearby Connections P2P walk groups added: host/join from the menu, verify matching code, share active bones, and mirror collected bones locally on both phones.
- No server or account is used for P2P.

## Fix 8
- Hides cafés, shops, restaurants and other POI labels/icons from the map.
- Keeps street and road names visible.
- Gives the bone counter more room inside the HUD and scales large counts down safely.
