package se.frasse.bonequest

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets

/** Small, server-free walk group using Google Nearby Connections. */
class NearbyWalkManager(
    context: Context,
    private val deviceName: String,
    private val bonesProvider: () -> List<Bone>,
    private val onStateChanged: (P2PState) -> Unit,
    private val onBonesReceived: (List<Bone>) -> Unit,
    private val onRemoteBoneTaken: (String) -> Unit,
) {
    private val client = Nearby.getConnectionsClient(context.applicationContext)
    private val serviceId = "se.frasse.bonequest.WALK_GROUP"
    private val strategy = Strategy.P2P_STAR
    private val connected = linkedSetOf<String>()
    private var hostMode = false
    private var state = P2PState()

    private fun publish(update: P2PState.() -> P2PState) {
        state = state.update()
        onStateChanged(state)
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val text = String(bytes, StandardCharsets.UTF_8)
            when {
                text.startsWith("BONE_TAKEN|") -> onRemoteBoneTaken(text.substringAfter('|'))
                text.startsWith("BONES|") -> decodeBones(text.substringAfter('|'))?.let(onBonesReceived)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) = Unit
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            publish {
                copy(
                    pendingEndpointId = endpointId,
                    pendingEndpointName = info.endpointName,
                    authenticationCode = info.authenticationDigits,
                    message = "Bekräfta samma kod på båda telefonerna"
                )
            }
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            if (resolution.status.isSuccess) {
                connected += endpointId
                client.stopDiscovery()
                publish {
                    copy(
                        connected = true,
                        connectedCount = this@NearbyWalkManager.connected.size,
                        pendingEndpointId = null,
                        pendingEndpointName = null,
                        authenticationCode = null,
                        message = "Promenadgruppen är ansluten"
                    )
                }
                if (hostMode) sendBones(bonesProvider())
            } else {
                publish {
                    copy(
                        pendingEndpointId = null,
                        pendingEndpointName = null,
                        authenticationCode = null,
                        message = "Anslutningen misslyckades"
                    )
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            connected -= endpointId
            publish {
                copy(
                    connected = this@NearbyWalkManager.connected.isNotEmpty(),
                    connectedCount = this@NearbyWalkManager.connected.size,
                    message = if (this@NearbyWalkManager.connected.isEmpty()) "Promenadgruppen kopplades från" else message
                )
            }
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            client.stopDiscovery()
            publish { copy(message = "Hittade ${info.endpointName} – ansluter…") }
            client.requestConnection(deviceName, endpointId, connectionCallback)
                .addOnFailureListener { publish { copy(message = "Kunde inte ansluta") } }
        }

        override fun onEndpointLost(endpointId: String) = Unit
    }

    fun host() {
        stop()
        hostMode = true
        publish { P2PState(active = true, hosting = true, message = "Väntar på en promenadkompis…") }
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(deviceName, serviceId, connectionCallback, options)
            .addOnFailureListener { e -> publish { copy(active = false, message = "P2P kunde inte starta: ${e.localizedMessage ?: "okänt fel"}") } }
    }

    fun join() {
        stop()
        hostMode = false
        publish { P2PState(active = true, hosting = false, message = "Letar efter promenadgrupp…") }
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(serviceId, discoveryCallback, options)
            .addOnFailureListener { e -> publish { copy(active = false, message = "P2P-sökning misslyckades: ${e.localizedMessage ?: "okänt fel"}") } }
    }

    fun acceptPending() {
        val endpointId = state.pendingEndpointId ?: return
        client.acceptConnection(endpointId, payloadCallback)
    }

    fun rejectPending() {
        val endpointId = state.pendingEndpointId ?: return
        client.rejectConnection(endpointId)
        publish { copy(pendingEndpointId = null, pendingEndpointName = null, authenticationCode = null, message = "Anslutningen avvisades") }
    }

    fun sendBoneTaken(boneId: String) = send("BONE_TAKEN|$boneId")

    private fun sendBones(bones: List<Bone>) {
        val array = JSONArray()
        bones.forEach { bone ->
            array.put(JSONObject().put("id", bone.id).put("lat", bone.latitude).put("lon", bone.longitude))
        }
        send("BONES|$array")
    }

    private fun decodeBones(raw: String): List<Bone>? = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(Bone(item.getString("id"), item.getDouble("lat"), item.getDouble("lon")))
            }
        }
    }.getOrNull()

    private fun send(text: String) {
        if (connected.isEmpty()) return
        client.sendPayload(connected.toList(), Payload.fromBytes(text.toByteArray(StandardCharsets.UTF_8)))
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connected.clear()
        hostMode = false
        publish { P2PState(message = if (active || connected) "P2P avstängt" else message) }
    }
}
