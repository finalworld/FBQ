package se.frasse.bonequest

data class GeoPoint(val latitude: Double, val longitude: Double)
data class Bone(val id: String, val latitude: Double, val longitude: Double)

data class P2PState(
    val active: Boolean = false,
    val hosting: Boolean = false,
    val connected: Boolean = false,
    val connectedCount: Int = 0,
    val pendingEndpointId: String? = null,
    val pendingEndpointName: String? = null,
    val authenticationCode: String? = null,
    val message: String? = null,
)
