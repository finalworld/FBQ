package se.frasse.bonequest

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class GameRepository(context: Context) {
    private val prefs = context.getSharedPreferences("frasse_bone_quest", Context.MODE_PRIVATE)

    fun boneCount(): Int = prefs.getInt("bone_count", 0)
    fun addCollectedBone() = prefs.edit().putInt("bone_count", boneCount() + 1).apply()

    fun loadBones(): List<Bone> {
        val raw = prefs.getString("bones", "[]") ?: "[]"
        val array = JSONArray(raw)
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(Bone(item.getString("id"), item.getDouble("lat"), item.getDouble("lon")))
            }
        }
    }

    fun saveBones(bones: List<Bone>) {
        val array = JSONArray()
        bones.forEach { bone ->
            array.put(JSONObject().put("id", bone.id).put("lat", bone.latitude).put("lon", bone.longitude))
        }
        prefs.edit().putString("bones", array.toString()).apply()
    }

    fun removeBone(id: String): List<Bone> {
        val updated = loadBones().filterNot { it.id == id }
        saveBones(updated)
        addCollectedBone()
        return updated
    }

    fun generatedNear(point: GeoPoint): Boolean {
        val lat = prefs.getString("generated_lat", null)?.toDoubleOrNull() ?: return false
        val lon = prefs.getString("generated_lon", null)?.toDoubleOrNull() ?: return false
        return distanceMeters(point.latitude, point.longitude, lat, lon) < 1800
    }

    fun markGenerated(point: GeoPoint) {
        prefs.edit().putString("generated_lat", point.latitude.toString())
            .putString("generated_lon", point.longitude.toString()).apply()
    }
}
