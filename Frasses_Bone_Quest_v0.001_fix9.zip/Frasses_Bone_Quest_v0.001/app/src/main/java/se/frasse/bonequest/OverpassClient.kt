package se.frasse.bonequest

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.*
import kotlin.random.Random

object OverpassClient {
    suspend fun generateBones(center: GeoPoint, radiusMeters: Int = 3500): List<Bone> = withContext(Dispatchers.IO) {
        val query = """
            [out:json][timeout:25];
            way(around:$radiusMeters,${center.latitude},${center.longitude})
              ["highway"~"^(footway|path|pedestrian|track)$"]
              ["access"!="private"];
            out geom;
        """.trimIndent()
        val encoded = URLEncoder.encode(query, "UTF-8")
        val connection = (URL("https://overpass-api.de/api/interpreter?data=$encoded").openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "FrassesBoneQuest/0.001 (Android test build)")
        }
        if (connection.responseCode !in 200..299) error("Overpass svarade ${connection.responseCode}")
        val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        val candidates = mutableListOf<GeoPoint>()
        val elements = json.getJSONArray("elements")
        for (i in 0 until elements.length()) {
            val geometry = elements.getJSONObject(i).optJSONArray("geometry") ?: continue
            if (geometry.length() < 2) continue
            val stride = max(1, geometry.length() / 5)
            var j = Random.nextInt(stride.coerceAtMost(geometry.length()))
            while (j < geometry.length()) {
                val node = geometry.getJSONObject(j)
                candidates += GeoPoint(node.getDouble("lat"), node.getDouble("lon"))
                j += stride
            }
        }
        val shuffled = candidates.shuffled()
        val picked = mutableListOf<Bone>()
        for (candidate in shuffled) {
            if (picked.all { distanceMeters(candidate.latitude, candidate.longitude, it.latitude, it.longitude) >= 300.0 }) {
                picked += Bone("${candidate.latitude}_${candidate.longitude}", candidate.latitude, candidate.longitude)
                if (picked.size >= 14) break
            }
        }
        picked
    }
}

fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val earth = 6_371_000.0
    val p1 = Math.toRadians(lat1)
    val p2 = Math.toRadians(lat2)
    val dp = Math.toRadians(lat2 - lat1)
    val dl = Math.toRadians(lon2 - lon1)
    val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
    return earth * 2 * atan2(sqrt(a), sqrt(1 - a))
}
