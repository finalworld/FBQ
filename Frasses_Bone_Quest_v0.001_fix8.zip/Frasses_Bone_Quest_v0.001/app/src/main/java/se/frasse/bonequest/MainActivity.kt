package se.frasse.bonequest

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Build
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.IconFactory
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideNavigationBar()
        MapLibre.getInstance(this)
        setContent { FrasseBoneQuestApp() }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideNavigationBar()
    }

    private fun hideNavigationBar() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.navigationBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            window.decorView.systemUiVisibility or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }
}

@Composable
private fun FrasseBoneQuestApp() {
    val context = LocalContext.current
    val repository = remember { GameRepository(context) }
    val tracker = remember { LocationTracker(context) }
    val scope = rememberCoroutineScope()

    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    var player by remember { mutableStateOf<GeoPoint?>(null) }
    var bones by remember { mutableStateOf(repository.loadBones()) }
    var boneCount by remember { mutableIntStateOf(repository.boneCount()) }
    var loadingBones by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>("Väntar på GPS…") }
    var followPlayer by remember { mutableStateOf(true) }
    var selectedBone by remember { mutableStateOf<Bone?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var p2pState by remember { mutableStateOf(P2PState()) }
    var pendingP2PAction by remember { mutableStateOf<String?>(null) }

    val nearbyManager = remember {
        NearbyWalkManager(
            context = context,
            deviceName = "Frasse-${Build.MODEL.take(12)}",
            bonesProvider = { bones },
            onStateChanged = { p2pState = it; it.message?.let { message -> status = message } },
            onBonesReceived = { incoming ->
                bones = incoming
                repository.saveBones(incoming)
                status = "Gemensamma ben synkade"
            },
            onRemoteBoneTaken = { boneId ->
                if (bones.any { it.id == boneId }) {
                    bones = repository.removeBone(boneId)
                    boneCount = repository.boneCount()
                    if (selectedBone?.id == boneId) selectedBone = null
                    status = "Promenadkompisen tog benet – ni fick båda +1"
                }
            }
        )
    }

    val p2pPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) {
            when (pendingP2PAction) {
                "host" -> nearbyManager.host()
                "join" -> nearbyManager.join()
            }
        } else {
            status = "Behörighet till enheter i närheten behövs för P2P"
        }
        pendingP2PAction = null
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permissionGranted = it
        if (!it) status = "GPS-behörighet behövs för att spela"
    }

    LaunchedEffect(Unit) {
        if (!permissionGranted) permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    LaunchedEffect(status, loadingBones) {
        if (status != null && !loadingBones) {
            delay(2_500)
            status = null
        }
    }

    DisposableEffect(permissionGranted) {
        if (permissionGranted) {
            tracker.start { location ->
                val point = GeoPoint(location.latitude, location.longitude)
                player = point
                status = if (location.accuracy <= 25) "GPS klar" else "GPS noggrannhet ±${location.accuracy.toInt()} m"
                if (!repository.generatedNear(point) && !loadingBones) {
                    loadingBones = true
                    scope.launch {
                        runCatching { OverpassClient.generateBones(point) }
                            .onSuccess { generated ->
                                if (generated.isNotEmpty()) {
                                    bones = (bones + generated).distinctBy { it.id }
                                    repository.saveBones(bones)
                                    repository.markGenerated(point)
                                    status = "${generated.size} ben placerade på stigar"
                                } else status = "Inga tydliga gångstigar hittades här"
                            }
                            .onFailure { status = "Kunde inte hämta stigar – försök igen senare" }
                        loadingBones = false
                    }
                }
            }
        }
        onDispose { tracker.stop() }
    }

    val nearBone = remember(player, bones) {
        val p = player ?: return@remember null
        bones.minByOrNull { distanceMeters(p.latitude, p.longitude, it.latitude, it.longitude) }
            ?.takeIf { distanceMeters(p.latitude, p.longitude, it.latitude, it.longitude) <= 25.0 }
    }
    LaunchedEffect(nearBone) { selectedBone = nearBone }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF08131B))) {
            GameMap(
                player = player,
                bones = bones,
                followPlayer = followPlayer,
                onManualMove = { followPlayer = false },
                onBoneTapped = { selectedBone = it },
                modifier = Modifier.fillMaxSize()
            )

            TopHud(
                count = boneCount,
                onMenu = { menuOpen = true },
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 4.dp)
            )

            if (!followPlayer) {
                FloatingActionButton(
                    onClick = { followPlayer = true },
                    modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(18.dp),
                    containerColor = androidx.compose.ui.graphics.Color(0xFF213141)
                ) { Text("◎", fontSize = 28.sp) }
            }

            selectedBone?.let { bone ->
                val p = player
                val distance = if (p == null) Double.MAX_VALUE else distanceMeters(p.latitude, p.longitude, bone.latitude, bone.longitude)
                if (distance <= 25) {
                    Button(
                        onClick = {
                            bones = repository.removeBone(bone.id)
                            boneCount = repository.boneCount()
                            nearbyManager.sendBoneTaken(bone.id)
                            selectedBone = null
                        },
                        modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp)
                            .height(64.dp).widthIn(min = 220.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF4E8F37))
                    ) { Text("TA BENET  •  ${distance.toInt()} m", fontWeight = FontWeight.Black, fontSize = 19.sp) }
                }
            }

            val statusText = if (loadingBones) "Letar gångstigar…" else status
            if (statusText != null) {
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 68.dp),
                    color = androidx.compose.ui.graphics.Color(0xB3141B20),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(statusText, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 12.sp)
                }
            }
        }

        if (menuOpen) {
            AlertDialog(
                onDismissRequest = { menuOpen = false },
                title = { Text("Frasse’s Bone Quest") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Version 0.001")
                        Text(
                            when {
                                p2pState.connected -> "P2P: ansluten (${p2pState.connectedCount})"
                                p2pState.active && p2pState.hosting -> "P2P: väntar på promenadkompis"
                                p2pState.active -> "P2P: söker promenadgrupp"
                                else -> "P2P: avstängt"
                            },
                            fontSize = 13.sp
                        )
                        if (!p2pState.connected && !p2pState.active) {
                            Button(onClick = {
                                menuOpen = false
                                pendingP2PAction = "host"
                                p2pPermissionLauncher.launch(requiredP2PPermissions())
                            }, modifier = Modifier.fillMaxWidth()) { Text("SKAPA PROMENADGRUPP") }
                            OutlinedButton(onClick = {
                                menuOpen = false
                                pendingP2PAction = "join"
                                p2pPermissionLauncher.launch(requiredP2PPermissions())
                            }, modifier = Modifier.fillMaxWidth()) { Text("HITTA PROMENADGRUPP") }
                        } else {
                            OutlinedButton(onClick = { nearbyManager.stop(); menuOpen = false }, modifier = Modifier.fillMaxWidth()) {
                                Text("KOPPLA FRÅN P2P")
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { (context as? Activity)?.finishAffinity() }) { Text("STÄNG APPEN") }
                },
                dismissButton = { TextButton(onClick = { menuOpen = false }) { Text("TILLBAKA") } }
            )
        }

        if (p2pState.pendingEndpointId != null) {
            AlertDialog(
                onDismissRequest = { nearbyManager.rejectPending() },
                title = { Text("Anslut promenadkompis?") },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(p2pState.pendingEndpointName ?: "Okänd telefon")
                        Spacer(Modifier.height(8.dp))
                        Text("Kontrollera att samma kod visas på båda:")
                        Text(p2pState.authenticationCode ?: "—", fontSize = 30.sp, fontWeight = FontWeight.Black)
                    }
                },
                confirmButton = { TextButton(onClick = { nearbyManager.acceptPending() }) { Text("ANSLUT") } },
                dismissButton = { TextButton(onClick = { nearbyManager.rejectPending() }) { Text("NEJ") } }
            )
        }
    }
}

@Composable
private fun TopHud(count: Int, onMenu: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().aspectRatio(1990f / 285f)) {
        Image(
            painter = painterResource(R.drawable.hud_top),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Box(Modifier.fillMaxHeight().width(92.dp).clickable(onClick = onMenu))
        Text(
            NumberFormat.getIntegerInstance(Locale.US).format(count),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 68.dp),
            color = androidx.compose.ui.graphics.Color(0xFFFFD88A),
            fontWeight = FontWeight.Black,
            fontSize = when { count < 1_000 -> 30.sp; count < 100_000 -> 26.sp; count < 10_000_000 -> 22.sp; else -> 18.sp }
        )
    }
}

@Composable
private fun GameMap(
    player: GeoPoint?, bones: List<Bone>, followPlayer: Boolean,
    onManualMove: () -> Unit, onBoneTapped: (Bone) -> Unit, modifier: Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    val playerMarkers = remember { mutableListOf<Marker>() }
    val boneMarkers = remember { mutableMapOf<String, Marker>() }

    val mapView = remember {
        MapView(context).apply {
            getMapAsync { libreMap ->
                map = libreMap
                // OpenFreeMap provides real worldwide OpenStreetMap vector tiles.
                // We start with its reliable base style; the RPG styling will be layered on gradually.
                libreMap.setStyle(Style.Builder().fromUri("https://tiles.openfreemap.org/styles/liberty")) { style ->
                    // Remove cafés, shops, restaurants and other map POIs while keeping road/street names.
                    val hiddenKeywords = listOf(
                        "poi", "shop", "restaurant", "cafe", "food", "hotel", "lodging",
                        "hospital", "pharmacy", "school", "college", "university", "parking",
                        "fuel", "bank", "atm", "airport", "transit", "station", "bus",
                        "ferry", "attraction", "museum", "zoo", "cinema", "theatre"
                    )
                    style.layers
                        .filter { layer -> hiddenKeywords.any { keyword -> layer.id.lowercase().contains(keyword) } }
                        .forEach { layer -> layer.setProperties(PropertyFactory.visibility(Property.NONE)) }
                }
                libreMap.cameraPosition = CameraPosition.Builder().target(LatLng(59.51, 17.63)).zoom(13.0).build()
                libreMap.addOnCameraMoveStartedListener { reason ->
                    if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) onManualMove()
                }
                libreMap.setOnMarkerClickListener { marker ->
                    val found = boneMarkers.entries.firstOrNull { it.value.id == marker.id }
                    found?.let { entry -> bones.firstOrNull { it.id == entry.key }?.let(onBoneTapped) }
                    true
                }
            }
        }
    }

    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        mapView.onCreate(null)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    androidx.compose.ui.viewinterop.AndroidView(factory = { mapView }, modifier = modifier)

    LaunchedEffect(map, player, followPlayer) {
        val m = map ?: return@LaunchedEffect
        playerMarkers.forEach(m::removeMarker); playerMarkers.clear()
        player?.let { p ->
            val marker = m.addMarker(MarkerOptions().position(LatLng(p.latitude, p.longitude))
                .icon(IconFactory.getInstance(context).fromBitmap(pawBitmap())))
            playerMarkers += marker
            if (followPlayer) m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(p.latitude, p.longitude), 16.2), 700)
        }
    }

    LaunchedEffect(map, bones) {
        val m = map ?: return@LaunchedEffect
        boneMarkers.values.forEach(m::removeMarker); boneMarkers.clear()
        bones.forEach { bone ->
            boneMarkers[bone.id] = m.addMarker(MarkerOptions().position(LatLng(bone.latitude, bone.longitude))
                .icon(IconFactory.getInstance(context).fromBitmap(boneBitmap(context, bone))))
        }
    }
}

private fun pawBitmap(): Bitmap {
    val size = 112
    val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = Color.argb(80, 0, 180, 255); c.drawCircle(56f, 59f, 50f, p)
    p.color = Color.WHITE; c.drawCircle(56f, 60f, 31f, p)
    p.color = Color.rgb(0, 105, 230)
    c.drawOval(35f, 54f, 77f, 91f, p)
    c.drawCircle(29f, 44f, 12f, p); c.drawCircle(48f, 30f, 12f, p); c.drawCircle(69f, 30f, 12f, p); c.drawCircle(87f, 44f, 12f, p)
    return b
}

private fun boneBitmap(context: android.content.Context, bone: Bone): Bitmap {
    val variants = intArrayOf(
        R.drawable.bone_01, R.drawable.bone_02, R.drawable.bone_03, R.drawable.bone_04,
        R.drawable.bone_05, R.drawable.bone_06, R.drawable.bone_07, R.drawable.bone_08,
        R.drawable.bone_09, R.drawable.bone_10, R.drawable.bone_11, R.drawable.bone_12,
    )
    // All bones are worth 1 in v0.001. The different sprites are already prepared for later rarities.
    val index = kotlin.math.abs(bone.id.hashCode()) % variants.size
    val source = BitmapFactory.decodeResource(context.resources, variants[index])
    return Bitmap.createScaledBitmap(source, 92, 64, false)
}

private fun requiredP2PPermissions(): Array<String> = buildList {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        add(Manifest.permission.BLUETOOTH_SCAN)
        add(Manifest.permission.BLUETOOTH_ADVERTISE)
        add(Manifest.permission.BLUETOOTH_CONNECT)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        add(Manifest.permission.NEARBY_WIFI_DEVICES)
    }
}.toTypedArray()
